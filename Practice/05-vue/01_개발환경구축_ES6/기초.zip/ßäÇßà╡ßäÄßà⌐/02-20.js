import defaultExport, {
  add,
  multiply,
} from "./lecure_module/02.modules/02-19modules3.js";

console.log(add(4));
console.log(defaultExport.getBase());
