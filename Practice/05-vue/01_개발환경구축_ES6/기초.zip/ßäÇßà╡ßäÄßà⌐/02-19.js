import { add, multiply } from "./lecure_module/02.modules/02-19-modules2.js";

console.log(add(4));
