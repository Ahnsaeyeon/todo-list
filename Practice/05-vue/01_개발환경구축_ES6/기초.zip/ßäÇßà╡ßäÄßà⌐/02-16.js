let name = "홍길동";
let age = 20;
let email = "gdhong@test.com";
let obj = { name, age, email };

console.log(obj);

// 출력값
// { name: '홍길동', age: 20, email: 'gdhong@test.com' }
